package ru.furniture.testTask;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import ru.furniture.testTask.models.Order;
import ru.furniture.testTask.repositories.OrderRepository;

import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class TestTaskApplicationTest {
    @Autowired
    private OrderRepository orderRepository;


    @Test
    public void contextLoads() {
    }
    @Test
    public void addOrdersTest(){
        int i;
        for (i = 1; i< 100; i++){
            Order order = new Order();
            order.setMnemonic("Chair" + i);

            orderRepository.save(order);
        }

    }

    @Test
    public void findAllProductsTest(){
        List<Order> orders = orderRepository.findAll();
        System.out.print(orders);
    }

}

