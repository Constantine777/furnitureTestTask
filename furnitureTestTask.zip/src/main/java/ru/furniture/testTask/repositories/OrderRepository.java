package ru.furniture.testTask.repositories;


import org.springframework.data.repository.CrudRepository;
import ru.furniture.testTask.models.Order;


import java.util.List;


@org.springframework.stereotype.Repository
public interface OrderRepository extends CrudRepository<Order, Long> {
    List<Order> findAll();
    List<Order> findAllWithOrderType(String orderType);
    List<Order> findById (Long id);
    Order save(Order persisted);
    void delete(Order persisted);

}



