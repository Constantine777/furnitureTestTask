package ru.furniture.testTask.models;

import javax.persistence.Column;
import javax.persistence.FetchType;

import javax.persistence.OneToMany;

public class Department extends IdentifiableEntity{

    @Column
    private String departmentName;


    @OneToMany(fetch = FetchType.LAZY)
    private Person person;

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

}
