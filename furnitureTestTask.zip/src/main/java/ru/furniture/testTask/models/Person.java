package ru.furniture.testTask.models;

import javax.persistence.*;

@Entity
public class Person extends IdentifiableEntity {

    @Column
    private String name;
    private String surname;
    private String patronymic;

    @OneToMany(fetch = FetchType.LAZY)
    private Order order;

    public String getName() {
        return name;
    }

    public void setName(String mnemonic) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) { this.surname = surname; }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

}
