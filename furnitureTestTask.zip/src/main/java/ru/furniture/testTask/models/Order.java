package ru.furniture.testTask.models;

import org.hibernate.annotations.Fetch;

import javax.persistence.*;

@Entity
public class Order extends IdentifiableEntity {

    @Column
    private String mnemonic;

    @ManyToOne(fetch = FetchType.LAZY)
    private OrderType orderType;

    public String getMnemonic() {
        return mnemonic;
    }

    public void setMnemonic(String mnemonic) {
        this.mnemonic = mnemonic;
    }

}
