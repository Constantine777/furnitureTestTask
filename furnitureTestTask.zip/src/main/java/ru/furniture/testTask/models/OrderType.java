package ru.furniture.testTask.models;

import javax.persistence.*;

@Entity
public class OrderType extends IdentifiableEntity {

    @Column
    private String typeName;

    @ManyToOne (fetch = FetchType.LAZY)
    private OrderTypeGroup typeGroup;

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public OrderTypeGroup getTypeGroup() {
        return typeGroup;
    }

    public void setTypeGroup(OrderTypeGroup typeGroup) {
        this.typeGroup = typeGroup;
    }
}
